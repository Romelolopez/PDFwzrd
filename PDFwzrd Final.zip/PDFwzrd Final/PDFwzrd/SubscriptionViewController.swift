//
//  SubscriptionViewController.swift
//  PDFwzrd
//
//  Created by Romelo Lopez on 4/25/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase


class SubscriptionViewController: UIViewController {
    let ref = Database.database().reference().root
    let userID : String = (Auth.auth().currentUser?.uid)!
    
    @IBOutlet weak var subscription: UILabel!
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        ref.child("users/\(userID)").observeSingleEvent(of: .value, with: {(snapshot) in
            print(snapshot.value!)
            
            let value = snapshot.value as? NSDictionary
            let school = value?["Subscription"] as? String ?? ""
            self.subscription.text = school
            
            
        })
        
    }
    
    @IBAction func subOne(_ sender: Any) {
        
        let disableMyButton = sender as? UIButton
        disableMyButton?.isEnabled = false
        ref.child("users").child(userID).updateChildValues(["Subscription":"one"])
        ref.child("users").child(userID).updateChildValues(["Books":"Reading"])
    /*
         ref.child("users").child(userID).child("Books").observe(.value, with: { (snapshot) in print("snapshot equals: \(snapshot.childrenCount)")
         let count = Int(snapshot.childrenCount)
         
         print("count equals: \(count)")
         })
         
 */
        ref.child("users/\(userID)").observeSingleEvent(of: .value, with: {(snapshot) in
            print(snapshot.value!)
            
            let value = snapshot.value as? NSDictionary
            let school = value?["Subscription"] as? String ?? ""
            self.subscription.text = school
            
            
        })
    }
    
    @IBAction func subTwo(_ sender: Any) {
        let disableMyButton = sender as? UIButton
        disableMyButton?.isEnabled = false
        ref.child("users").child(userID).updateChildValues(["Subscription":"two"])
        ref.child("users").child(userID).updateChildValues(["Books":"Reading"])
        
        ref.child("users/\(userID)").observeSingleEvent(of: .value, with: {(snapshot) in
            print(snapshot.value!)
            
            let value = snapshot.value as? NSDictionary
            let school = value?["Subscription"] as? String ?? ""
            self.subscription.text = school
            
            
        })
    }
    
    @IBAction func subThree(_ sender: Any) {
        let disableMyButton = sender as? UIButton
        disableMyButton?.isEnabled = false
        ref.child("users").child(userID).updateChildValues(["Subscription":"three"])
        ref.child("users").child(userID).updateChildValues(["Books":"Reading"])
        
        ref.child("users/\(userID)").observeSingleEvent(of: .value, with: {(snapshot) in
            print(snapshot.value!)
            
            let value = snapshot.value as? NSDictionary
            let school = value?["Subscription"] as? String ?? ""
            self.subscription.text = school
            
            
        })
    }
    
    @IBAction func subUnlimited(_ sender: Any) {
    
        ref.child("users").child(userID).updateChildValues(["Subscription":"Unlimited"])
        ref.child("users").child(userID).updateChildValues(["Books":"Reading"])
        
        ref.child("users/\(userID)").observeSingleEvent(of: .value, with: {(snapshot) in
            print(snapshot.value!)
            
            let value = snapshot.value as? NSDictionary
            let school = value?["Subscription"] as? String ?? ""
            self.subscription.text = school
            
            
        })
    }
    
    @IBAction func unsubscribe(_ sender: Any) {
        ref.child("users/\(userID)/Books").removeValue { error, _ in
            if error != nil {
                print("error")
            }
        }
            self.ref.child("users/\(self.userID)/Subscription").removeValue { error, _ in
                if error != nil {
                    print("error")
                }
        }
                self.ref.child("users").child(self.userID).updateChildValues(["Subscription":"Unsubscribed"])
                self.ref.child("users").child(self.userID).updateChildValues(["Books":"Reading"])
        
        ref.child("users/\(userID)").observeSingleEvent(of: .value, with: {(snapshot) in
            print(snapshot.value!)
            
            let value = snapshot.value as? NSDictionary
            let school = value?["Subscription"] as? String ?? ""
            self.subscription.text = school
            
            
        })
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
