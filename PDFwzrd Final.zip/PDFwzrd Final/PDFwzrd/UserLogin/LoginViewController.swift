//
//  LoginViewController.swift
//  PDFwzrd
//
//  Created by Romelo Lopez on 2/26/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import Foundation
import UIKit
import Firebase
import FirebaseDatabase

class LoginViewController: UIViewController {
    
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBAction func loginAction(_ sender: Any) {
        Auth.auth().signIn(withEmail: email.text!, password: password.text!) { (user, error) in
            if error == nil{
                
                Database.database().reference().child("users/\(user!.user.uid)/type").observeSingleEvent(of: .value, with: {
                    (snapshot) in
                    
                    switch snapshot.value as? String {
                    // If our user is admin...
                    case "admin":
                        // ...redirect to the admin page
                        self.performSegue(withIdentifier: "loginToAdmin", sender: self)
                        print ("hello")
                        // If out user is a regular user...
                        
                    case "student":
                        // ...redirect to the user page
                        self.performSegue(withIdentifier: "loginToHome", sender: self)
                        // If the type wasn't found...
                        
                        
                    default:
                        // ...print an error
                        print("Error: Couldn't find type for user \(user!.user.uid)")
                        //print ("it works")
                        //self.adminErrorLabel.text = "You are not authorized to log in here"
                    }
                })
            }else{
                let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                
                alertController.addAction(defaultAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    
}


